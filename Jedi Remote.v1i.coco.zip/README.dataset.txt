# Jedi Remote > 2024-05-26 8:59pm
https://universe.roboflow.com/jedi-remote/jedi-remote-aqfyg

Provided by a Roboflow user
License: CC BY 4.0

